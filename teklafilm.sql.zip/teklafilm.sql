-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2019 at 11:04 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teklafilm`
--

-- --------------------------------------------------------

--
-- Table structure for table `free_articles`
--

CREATE TABLE `free_articles` (
  `id` int(10) NOT NULL,
  `type` int(1) NOT NULL,
  `title` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `thumb` varchar(250) NOT NULL,
  `des` text NOT NULL,
  `file_url` varchar(250) NOT NULL,
  `visits` int(10) NOT NULL DEFAULT '0',
  `downloads` int(10) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `free_articles`
--

INSERT INTO `free_articles` (`id`, `type`, `title`, `slug`, `thumb`, `des`, `file_url`, `visits`, `downloads`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'qweqwe ds sd fg a gh as fg as df as', 'qweqwe', 'panel/files/61308052551d4d-fcce-40ea-b7fb-a4ba97c7e8ec.jpg', '<p style=text-align: left>as sdf&nbsp qweqwesdfsd sdfsdf sdf sdf sdf sdf ds</p>', 'panel/files/231604clock.html', 0, 0, 1, '2019-07-04 06:57:48', '2019-07-04 09:12:27'),
(2, 1, 'qweqwe s dsvs ', 'qweqwe-s-dsvs-', 'panel/files/510623i44ndex.jpg', '<p style=text-align: left>sdv sd sd s qweqwe</p>', 'panel/files/559182Mabna-gateway-manual-2.1.1.5-Token.pdf', 0, 0, 1, '2019-07-04 06:58:51', '2019-07-04 07:50:59'),
(3, 2, 'Highcharts Demo', 'Highcharts-Demo', 'panel/files/80483052551d4d-fcce-40ea-b7fb-a4ba97c7e8ec.jpg', '<p style=text-align: left>asd sds s asdas fgfg tyu yuikjhmnb&nbsp</p>', 'panel/files/672401Mabna-gateway-manual-2.1.1.5-Token.pdf', 0, 0, 1, '2019-07-04 07:03:27', '2019-07-04 07:54:06'),
(4, 2, 'Highcharts Demo', 'Highcharts-Demo', 'panel/files/835210photo5771455157354212939.jpg', '<p style=text-align: left>asd sds s asdas fgfg tyu yuikjhmnb&nbsp</p>', 'panel/files/25713photo5771455157354212950.jpg', 0, 0, 1, '2019-07-04 07:04:44', '2019-07-04 07:54:04'),
(5, 3, 'weewr sdf', 'weewr', 'panel/files/931842photo5771455157354212945.jpg', '<p style=text-align: left>werewrewr sdfds&nbsp</p>', 'panel/files/741875Mabna-gateway-manual-2.1.1.5-Token.pdf', 0, 0, 1, '2019-07-04 07:10:04', '2019-07-04 08:12:09');

-- --------------------------------------------------------

--
-- Table structure for table `pays`
--

CREATE TABLE `pays` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `video_id` int(10) NOT NULL,
  `amount` float NOT NULL,
  `t_code` varchar(250) NOT NULL,
  `date_time` varchar(250) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `id` int(3) NOT NULL,
  `title` varchar(250) NOT NULL,
  `des` varchar(250) NOT NULL,
  `image_url` varchar(250) NOT NULL,
  `link` varchar(250) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `title`, `des`, `image_url`, `link`, `status`, `created_at`, `updated_at`) VALUES
(1, 'first slider', 'first slider description first slider description first slider description', 'panel/files/1094431.jpg', 'http://localhost:3000', 1, '2019-07-04 13:21:12', '2019-07-04 13:24:29'),
(2, 'Second slider', 'Second slider Second slider Second slider Second slider', 'panel/files/349794agif_r10_d20_160x90.gif', 'Second slider', 1, '2019-07-04 13:23:06', '2019-07-04 13:24:40'),
(3, 'Third slider ', 'Third slider Third slider Third slider Third slider Third slider Third slider Third slider Third slider Third slider Third slider Third slider ', 'panel/files/5126263.jpg', 'Third slider ', 1, '2019-07-04 13:23:45', '2019-07-04 13:24:40'),
(4, 'Fourth Slider ', 'Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider Fourth Slider ', 'panel/files/3133565.jpg', 'Fourth Slider ', 1, '2019-07-04 13:24:18', '2019-07-04 13:24:38'),
(5, 'Fifth Slider ', 'Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider Fifth Slider ', 'panel/files/987597images.jpg', 'Fifth Slider ', 1, '2019-07-04 13:29:07', '2019-07-04 13:33:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `family` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `email_val` varchar(250) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `family`, `email`, `password`, `email_val`, `status`, `created_at`, `updated_at`) VALUES
(1, 'system', 'administrator', 'sarayi.cactux@gmail.com', '$2y$10$MKsQ3UZ0WZhG5AA36iuKeOuUPVLSb5qeUllVqJO23OvMkppVJC/a2', '', 0, '2019-07-03 06:43:39', '2019-07-03 09:10:58'),
(2, 'mo', 'sa', 'sa.d@gam.com', '$2y$10$Xd7vV6.yHAlTTM4TpyGbuOwceQsYtZZR7fRVKFTxm91jwnU.WRBfS', '', 0, '2019-07-10 12:14:57', '2019-07-10 12:14:57'),
(3, 'sdfsd', 'dsfsdfs', 'sdfsd@sdf.co', '$2y$10$lQQeOzekCpVe04lezuwyeu2YgUyM/xkdT/.lvsUp9EUN2LhsT.cva', '', 0, '2019-07-10 12:28:24', '2019-07-10 12:28:25'),
(4, 'mohamad', 'sarayi', 'sarayi@gmail.com', '$2y$10$xn8e4AVtVJaJMqzWU3HqFuKjw4tAVaAxSsv6BIiZD.64JGzM67hLK', '', 0, '2019-07-10 12:29:08', '2019-07-10 12:29:08'),
(10, 'mohamad', 'sarayi', 'myehghagh@gmail.com', '$2y$10$B2jFKmokR5r9rccSbCj9beFzT7.qAe7X0W/8np0yjZuljsjTLxkQO', '6b8117d5b67f8e6883895889922f18a8', 1, '2019-07-10 13:34:30', '2019-07-10 15:04:34');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(10) NOT NULL,
  `title` varchar(250) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `thumb` varchar(250) NOT NULL,
  `des` text NOT NULL,
  `text` text NOT NULL,
  `main_file` varchar(250) NOT NULL,
  `demo_file` varchar(250) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `visits` int(10) NOT NULL DEFAULT '0',
  `downloads` int(10) NOT NULL DEFAULT '0',
  `sales` int(10) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `videos`
--

INSERT INTO `videos` (`id`, `title`, `slug`, `thumb`, `des`, `text`, `main_file`, `demo_file`, `status`, `visits`, `downloads`, `sales`, `created_at`, `updated_at`) VALUES
(1, 'Highcharts Demo', 'Highcharts-Demo', 'panel/files/62590814.jpg', 'werwer 2323', '<p>werwerffffffffffffffffffffffffffff fffffffffff dddddddddddddd&nbsp &nbsp &nbsp &nbspfffffffff</p>', 'panel/F7L97@I^ktA/529706t_video5915781773328909548.mp4', 'panel/files/183623A4yFkzAz.mp4', 1, 0, 0, 0, '2019-07-04 09:07:04', '2019-07-04 09:21:45'),
(2, 'sdasd', 'sdasd', 'panel/files/815145i44ndex.jpg', 'asdasd', '<p>sadasdasdas</p>', 'panel/F7L97@I^ktA/21245t_video5951596732516140175.mp4', 'panel/files/175000t_video5951596732516140175.mp4', 1, 0, 0, 0, '2019-07-04 09:37:04', '2019-07-04 09:37:59');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `free_articles`
--
ALTER TABLE `free_articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `free_articles`
--
ALTER TABLE `free_articles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
