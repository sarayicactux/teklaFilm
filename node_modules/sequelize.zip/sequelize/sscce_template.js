'use strict';

/*
 * Copy this file to ./sscce.js
 * Add code from issue
 * npm run sscce-{dialect}
 */

const Sequelize = require('./index');
const sequelize = require('./test/support').createSequelizeInstance();
